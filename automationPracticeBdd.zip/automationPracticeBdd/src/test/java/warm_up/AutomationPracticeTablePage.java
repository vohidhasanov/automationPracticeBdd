package warm_up;

import com.automationpractice.utilities.CommonPage;
import com.automationpractice.utilities.DriverHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.*;

import java.util.Arrays;
import java.util.List;

public final class AutomationPracticeTablePage extends CommonPage {
    private static AutomationPracticeTablePage automationPracticeTablePage;

    public static AutomationPracticeTablePage getAutomationPracticeTablePage (WebDriver driver) {
        if (automationPracticeTablePage == null) automationPracticeTablePage = new AutomationPracticeTablePage(driver);
        return automationPracticeTablePage;
    }

    private AutomationPracticeTablePage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    protected boolean isLoaded() {
        return false;   //  return header.getText().equals("some text");
    }

    @FindBy(tagName = "h1")  private WebElement header;
  @FindBy(css = "#content [summary='Sample Table']") private WebElement tableElement;

  @FindBys({
           @FindBy(how = How.CSS, using = "#content [summary='Sample Table'] tr"),
//          @FindBy(css = "#content [summary='Sample Table']tr")  // It is old way to do it
    })     private List<WebElement> rows;

  //@FindBys({@FindBy (id="")}) private WebElement colomns;

// public boolean isLoaded () {
//     return header.getText().equals("some text");
//}

  public String getHeader () {
    return header.getText();
    }

  public boolean isTableDisplayed () {
    return tableElement.isDisplayed();
  }

  public void printAllValues () {
    int rowNum = rows.size();
    for (int index = 0; index<rowNum; index++) {
        int colomns = rows.get(index).findElements(By.tagName("td")).size();
        for (int colomnNumber = 0; colomnNumber<colomns; colomnNumber++) {
            System.out.print(rows.get(colomnNumber).getText()+" " );
        }
        System.out.println();
    }
     System.out.println();
  }
}
