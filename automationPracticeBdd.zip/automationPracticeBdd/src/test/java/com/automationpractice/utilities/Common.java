package com.automationpractice.utilities;

import com.github.javafaker.Faker;
import org.apache.log4j.Logger;

import java.io.File;
 public final class Common {
    private static Logger logger = Logger.getLogger(Common.class);


private Common () {}

    public static void sleep (int second) {
        try {
            int secondsSleep = second*1000;
            Thread.sleep(secondsSleep);
            logger.info("sleep for "+secondsSleep+" seconds");
        } catch (InterruptedException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        }
    }



    public static void deleteFiles (String directoryPath) {
        File file = new File  (System.getProperty("user_id")+directoryPath);
        for ( File file1: file.listFiles()) {
            boolean isfileDeleted =  file1.delete();
            if (isfileDeleted) System.out.println("File \"" +file1.toPath().getFileName()+"\" deleted");
            System.out.println("File \"" +file1.toPath().getFileName()+"\" not deleted");
              }

    }

    public static void failTest (String errorMessage) {
        throw new RuntimeException(errorMessage);

    }

//    public static void main(String[] args) {
//        WebDriver driver = Driver.driver.getDriver("chrome");
//        driver.get("https://email-verify.my-addr.com/list-of-most-popular-email-domains.php");
//        List<WebElement> rowElement = driver.findElements(By.xpath("(//h2[text()='Top 100']/..//table//tr)"));
//
//        for (int x=1; x<=rowElement.size(); x++) {
//        String email = driver.findElement(By.xpath("((//h2[text()='Top 100']/..//table//tr)["+ x+"]//td)[3]")).getText();
//        email = "\"@"+email+"\", ";
//        System.out.print(email);
//        }
//
//
//
//    }

}
