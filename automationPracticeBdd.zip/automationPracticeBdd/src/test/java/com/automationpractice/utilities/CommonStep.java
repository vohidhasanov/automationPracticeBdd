package com.automationpractice.utilities;

import org.openqa.selenium.WebDriver;

public class CommonStep {

    protected WebDriver getDriver() {
    return DriverFarctory.getDriver();
    }

    protected static void closeDriver() {

        DriverFarctory.closeDriver();
    }

}
